import { ContrasenaPipe } from './contrasena.pipe';

describe('ContrasenaPipe', () => {
  it('create an instance', () => {
    const pipe = new ContrasenaPipe();
    expect(pipe).toBeTruthy();
  });
});
